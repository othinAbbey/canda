import { auditRepo } from "../repos/audit.js";
import { billingRepo } from "../repos/billing.js";
import { boqRepo } from "../repos/boq.js";
import { catalogRepo } from "../repos/catalog.js";
import { filesRepo } from "../repos/files.js";
import { messagesRepo } from "../repos/messages.js";
import { organizationsRepo } from "../repos/organizations.js";
import { projectStatsRepo } from "../repos/projectStats.js";
import { resourcesRepo } from "../repos/resources.js";
import { usersRepo } from "../repos/users.js";
import { rolesRepo } from "../repos/roles.js";
import { createAccounts } from "./accounts.js";
import { createAudit } from "./audit.js";
import { createBilling } from "./billing.js";
import { createBoq } from "./boq.js";
import { createBoqClient } from "./boqClient.js";
import { createContact } from "./contact.js";
import { createFiles } from "./files.js";
import { createForms } from "./forms.js";
import { createOrganizations } from "./organizations.js";
import { createProposals } from "./proposals.js";
import { createResources } from "./resources.js";
import { createRoles } from "./roles.js";
import { createSchedule } from "./schedule.js";
import { createSourcing } from "./sourcing.js";
import { createSummary } from "./summary.js";
import { createTenderWork } from "./tenderWork.js";
import { createTenders } from "./tenders.js";
import { createLimiter } from "../http/rateLimit.js";

/** Builds every service from the database and config. The only place that wires repos to services. */
export function createServices({ db, config, secret, boqClient = createBoqClient(config.boq), tenderProviders }) {
  const users = usersRepo(db), resourcesR = resourcesRepo(db), catalog = catalogRepo(db), auditR = auditRepo(db);
  const audit = createAudit(auditR);
  const limiter = createLimiter({ max: 10, windowMs: 5 * 60_000 });
  const roles = createRoles({ repo: rolesRepo(db), audit });
  const schedule = createSchedule({ db, audit });
  const resources = createResources({ repo: resourcesR, audit, hooks: { tasks: schedule.checkTask } });
  const billing = createBilling({ billing: billingRepo(db), users, audit, config });
  const organizations = createOrganizations({ repo: organizationsRepo(db) });
  return {
    audit, resources, billing, schedule, roles, organizations,
    accounts: createAccounts({ db, users, roles, audit, config, secret, limiter }),
    summary: createSummary({ resources, stats: projectStatsRepo(db), audit: auditR, files: filesRepo(db) }),
    sourcing: createSourcing({ resources, catalog }),
    proposals: createProposals({ db, catalog, audit }),
    forms: createForms({ db, audit }),
    files: createFiles({ files: filesRepo(db), resources, audit, config }),
    boq: createBoq({ boq: boqRepo(db), client: boqClient, billing, audit, config }),
    tenders: createTenders({ db, providers: tenderProviders }),
    tenderWork: createTenderWork({ db, roles, audit }),
    contact: createContact({ messages: messagesRepo(db), audit, limiter }),
  };
}
