import { RESOURCES, clean } from "../domain/resources.js";
import { notFound } from "../errors.js";

const label = (r) => String(r.name || r.title || r.item || r.work || (r.price != null ? `rate ${r.price}` : r.id)).slice(0, 80);

/** Create / read / update / delete for every table in RESOURCES, with validation and audit in one place.
 *  `hooks[table](values, existing)` may check or adjust the values before they are saved (throw a ValidationError to refuse). */
export function createResources({ repo, audit, hooks = {} }) {
  const projectOf = (table, row) => { const f = RESOURCES[table].projectOf; return f ? row[f] : null; };
  const must = async (table, id, organizationId) => { const r = await repo.get(table, id, organizationId); if (!r) throw notFound(); return r; };

  return {
    list: (table, { project, organizationId } = {}) => repo.list(table, { project, organizationId }),
    get: must,
    async create(actor, table, body) {
      const values = clean(table, body);
      if (RESOURCES[table].projectOf && table !== "projects" && !(await repo.get("projects", values.project, actor.organization_id))) throw notFound("project not found");
      if (hooks[table]) await hooks[table](values, null);
      const row = await repo.insert(table, values, actor.id, actor.organization_id);
      await audit.log(actor, { action: "create", entity: table, id: row.id, project: projectOf(table, row), summary: label(row) });
      return row;
    },
    async update(actor, table, id, body) {
      const before = await must(table, id, actor.organization_id);
      const values = clean(table, body, { partial: true });
      if (RESOURCES[table].projectOf && table !== "projects" && values.project && !(await repo.get("projects", values.project, actor.organization_id))) throw notFound("project not found");
      if (hooks[table]) await hooks[table](values, before);
      const row = await repo.update(table, id, values, actor.organization_id);
      if (!row) throw notFound();
      const changes = {};
      for (const k of Object.keys(RESOURCES[table].cols)) if (before[k] !== row[k]) changes[k] = [before[k] ?? null, row[k] ?? null];
      await audit.log(actor, { action: "update", entity: table, id, project: projectOf(table, row), summary: `${label(row)}: ${Object.keys(changes).join(", ") || "no change"}`, changes });
      return row;
    },
    async remove(actor, table, id) {
      const before = await must(table, id, actor.organization_id);
      const removed = await repo.remove(table, id, actor.organization_id);
      if (!removed) throw notFound();
      await audit.log(actor, { action: "delete", entity: table, id, project: projectOf(table, before), summary: label(before), changes: before });
    },
  };
}
